package MyHyperVideo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Scrollbar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.WritableRaster;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.Stack;
import java.util.StringJoiner;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class PlayVideo {
  static BufferedImage leftimg;
  static Stack<BufferedImage> last_leftimgs;
  static BufferedImage rightimg;
  static int  width = 352;
  static int height= 288;
  int[][] imagedata = new int[height][width];
  static JLabel lbIm1;
  static JLabel lbIm2;
  static JFrame frame;
  static JTextField fieldtext1;
  static JTextField fieldtext2;
  static String File1Prefix;
  static String File2Prefix;
  static Scrollbar scrollbar2;
  static Scrollbar scrollbar1;
  static JTable jtable;
  static JScrollPane jsPane;
  static int current_scroll_value1;
  static int current_scroll_value2;
  static JPopupMenu Popup_Menu;
  static GridBagConstraints c;
  public static void main(String[] args) {
	  PlayVideo pv = new PlayVideo();
	  leftimg = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
	  rightimg = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
	  last_leftimgs = new Stack<>();
	  //File1Prefix = "/Users/gracelt/Downloads/USC/USCOne/USCOne";
	  //File2Prefix = "/Users/gracelt/Downloads/USC/USCTwo/USCTwo";
	  
	  //pv.readData(File1Prefix + "0001.rgb",leftimg);
	  //pv.readData(File2Prefix + "0001.rgb", rightimg);
	  
	  frame = new JFrame();
	  GridBagLayout gLayout = new GridBagLayout();
	  frame.getContentPane().setLayout(gLayout);
	  c = new GridBagConstraints();
	  
	 // JLabel importFvideo = new JLabel("import primary video:");
	 // JLabel importSvideo = new JLabel("import secondary video:");
	  JTextField FvideoText = new JTextField(5);
	  JTextField SvideoText = new JTextField(5);
	  JButton btn_import1 = new JButton("import primary video");
	  JButton btn_import2 = new JButton("import secondary video");
	  JButton connect_video = new JButton("Connect Video");
	  JButton save_file = new JButton("Save File");
	  JLabel lbText1 = new JLabel("Primary Video");
	  lbText1.setHorizontalAlignment(SwingConstants.CENTER);
	  JLabel lbText2 = new JLabel("Secondary Video");
	  lbText2.setHorizontalAlignment(SwingConstants.CENTER);
	  
	  c.fill = GridBagConstraints.HORIZONTAL;
	  c.anchor = GridBagConstraints.CENTER;
	  c.weightx = 0.5;
	  c.gridx = 0;
	  c.gridy = 0;
	  frame.getContentPane().add(lbText1,c);
	  
	  c.fill = GridBagConstraints.HORIZONTAL;
	  c.anchor = GridBagConstraints.CENTER;
	  c.weightx = 0.5;
	  c.gridx = 1;
	  c.gridy = 0;
	  frame.getContentPane().add(lbText2,c);
	  
	  lbIm1 = new JLabel(new ImageIcon(leftimg));
	  c.fill = GridBagConstraints.HORIZONTAL;
	  c.gridx = 0;
	  c.gridy = 1;
	  frame.getContentPane().add(lbIm1,c);
	  
	  lbIm2 = new JLabel(new ImageIcon(rightimg));
	  c.fill = GridBagConstraints.HORIZONTAL;
	  c.gridx = 1;
	  c.gridy = 1;
	  frame.getContentPane().add(lbIm2,c);
	  
	  fieldtext1 = new JTextField(25);
	  fieldtext1.setText("Frame 1");
	  fieldtext1.setFocusable(false);
	  fieldtext1.setBorder(null);
	  fieldtext1.setEditable(false);
	  fieldtext1.setHorizontalAlignment(JTextField.CENTER);
	  c.fill = GridBagConstraints.HORIZONTAL;
	  c.gridx = 0;
	  c.gridy = 2;
	  frame.getContentPane().add(fieldtext1,c);
	  
	  fieldtext2 = new JTextField(25);
	  fieldtext2.setText("Frame 1");
	  fieldtext2.setFocusable(false);
	  fieldtext2.setEditable(false);
	  fieldtext2.setBorder(null);
	  fieldtext2.setHorizontalAlignment(JTextField.CENTER);
	  c.fill = GridBagConstraints.HORIZONTAL;
	  c.gridx = 1;
	  c.gridy = 2;
	  frame.getContentPane().add(fieldtext2,c);
	  
	  scrollbar1 = new Scrollbar(Scrollbar.HORIZONTAL, 1, 10, 1, 9001);
	  scrollbar1.setEnabled(false);
	  scrollbar1.addAdjustmentListener(new AdjustmentListener() {
		  public void adjustmentValueChanged(AdjustmentEvent e) {
			  current_scroll_value1 = scrollbar1.getValue();
			  String temp = "";
			  if(current_scroll_value1 < 10)
				  temp = "000";
			  else if(current_scroll_value1 < 100)
				  temp = "00";
			  else if(current_scroll_value1 < 1000)
				  temp = "0";
			  System.out.print(File1Prefix + temp + current_scroll_value1+".rgb");
			  pv.readData(File1Prefix + temp + current_scroll_value1 +".rgb",leftimg);
			  BufferedImage temp_img = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
			  temp_img.setData(leftimg.getData());
			  last_leftimgs.push(temp_img);
			  frame.getContentPane().remove(lbIm1);
			  frame.repaint();
			  lbIm1 = new JLabel(new ImageIcon(leftimg));
			  c.fill = GridBagConstraints.HORIZONTAL;
			  c.gridx = 0;
			  c.gridy = 1;
			  frame.getContentPane().add(lbIm1,c);
			  frame.getContentPane().validate();
			  
			  fieldtext1.setText("Frame" + " " + current_scroll_value1);
		  }
		  
	  });
	  scrollbar1.setUnitIncrement(1);
	  scrollbar1.setBlockIncrement(1);
	  c.fill = GridBagConstraints.HORIZONTAL;
	  c.gridx = 0;
	  c.gridy = 3;
	  frame.getContentPane().add(scrollbar1,c);
	  
	  scrollbar2 = new Scrollbar(Scrollbar.HORIZONTAL, 1, 10, 1, 9001);
	  scrollbar2.setEnabled(false);
	  scrollbar2.addAdjustmentListener(new AdjustmentListener() {
		  public void adjustmentValueChanged(AdjustmentEvent e) {
			  current_scroll_value2 = scrollbar2.getValue();
			  String temp = "";
			  if(current_scroll_value2 < 10)
				  temp = "000";
			  else if(current_scroll_value2 < 100)
				  temp = "00";
			  else if(current_scroll_value2 < 1000)
				  temp = "0";
			  System.out.print(File2Prefix + temp + current_scroll_value2+".rgb");
			  pv.readData(File2Prefix + temp + current_scroll_value2 +".rgb",rightimg);
			  frame.getContentPane().remove(lbIm2);
			  frame.repaint();
			  lbIm2 = new JLabel(new ImageIcon(rightimg));
			  c.fill = GridBagConstraints.HORIZONTAL;
			  c.gridx = 1;
			  c.gridy = 1;
			  frame.getContentPane().add(lbIm2,c);
			  frame.getContentPane().validate();
			  
			  fieldtext2.setText("Frame" + " " + current_scroll_value2);
		  }
		  
	  });
	  scrollbar2.setUnitIncrement(1);
	  scrollbar2.setBlockIncrement(1);
	  c.fill = GridBagConstraints.HORIZONTAL;
	  c.gridx = 1;
	  c.gridy = 3;
	  frame.getContentPane().add(scrollbar2,c);
	  
	  c.fill = GridBagConstraints.HORIZONTAL;
	  c.anchor = GridBagConstraints.WEST;
	  c.weightx = 0.5;
	  c.gridx = 0;
	  c.gridy = 4;
	  frame.getContentPane().add(FvideoText,c);
//	  
	  c.fill = GridBagConstraints.HORIZONTAL;
	  c.anchor = GridBagConstraints.WEST;
	  c.weightx = 0.5;
	  c.gridx = 1;
	  c.gridy = 4;
	  frame.getContentPane().add(btn_import1,c);
	  btn_import1.addActionListener(new ActionListener() {
		  public void actionPerformed(ActionEvent e) {
			  File1Prefix = FvideoText.getText();
			  if(File1Prefix.equals("")) {
				  JOptionPane.showMessageDialog(null,"Please enter your filepath!");
			  }else {
				  JOptionPane.showMessageDialog(null,"Your filepath is valid!");
				  scrollbar1.setEnabled(true);
				  scrollbar1.setValue(1);
				  fieldtext1.setText("Frame 1");
				  pv.readData(File1Prefix +"0001.rgb",leftimg);
				  BufferedImage temp_img = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
				  temp_img.setData(leftimg.getData());
				  last_leftimgs.push(temp_img);
				  lbIm1 = new JLabel(new ImageIcon(leftimg));
				  c.fill = GridBagConstraints.HORIZONTAL;
				  c.gridx = 0;
				  c.gridy = 1;
				  frame.getContentPane().add(lbIm1,c);
				  frame.getContentPane().validate();
			  }
		  }
	  });
	  btn_import2.addActionListener(new ActionListener() {
		  public void actionPerformed(ActionEvent e) {
			  
			  File2Prefix = SvideoText.getText();
			  if(File2Prefix.equals("")) {
				  JOptionPane.showMessageDialog(null,"Please enter your filepath!");
			  }else {
				  JOptionPane.showMessageDialog(null,"Your filepath is valid!");
				  scrollbar2.setEnabled(true);
				  scrollbar2.setValue(1);
				  fieldtext2.setText("Frame 1");
				  pv.readData(File2Prefix +"0001.rgb",rightimg);
				  lbIm2 = new JLabel(new ImageIcon(rightimg));
				  c.fill = GridBagConstraints.HORIZONTAL;
				  c.gridx = 1;
				  c.gridy = 1;
				  frame.getContentPane().add(lbIm2,c);
				  frame.getContentPane().validate();
			  }
		  }
	  });
	  lbIm1.addMouseListener(new MouseAdapter() {
		  int leftx;
		  int lefty;
		  int rightx;
		  int righty;
		  public void mousePressed(MouseEvent e) {
			   leftx = e.getX();
			   lefty = e.getY();
			   System.out.print("x:"+leftx+",y:"+lefty);
		  }
		  public void mouseReleased(MouseEvent e) {
			   rightx = e.getX();
			   righty = e.getY();
			   BufferedImage temp_img = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
			   temp_img.setData(leftimg.getData());
			   last_leftimgs.push(temp_img);
			   System.out.println("x:"+rightx+",y:"+righty);
				  Graphics2D g = leftimg.createGraphics();
			      g.setColor(Color.GREEN);//画笔颜色
			      g.drawRect(leftx, lefty, Math.abs(leftx-rightx), Math.abs(lefty-righty));
			      g.drawImage(leftimg, 0, 0, null);
			      frame.getContentPane().remove(lbIm1);
				  frame.repaint();
				  lbIm1 = new JLabel(new ImageIcon(leftimg));
				  c.fill = GridBagConstraints.HORIZONTAL;
				  c.gridx = 0;
				  c.gridy = 1;
				  frame.getContentPane().add(lbIm1,c);
				  frame.getContentPane().validate();
				  
				  //record coordinates
				  int currentvalue1 = scrollbar1.getValue();
//				  
				  
				  int currentvalue2 = scrollbar2.getValue();
				  
				  
				  String primary_video =  File1Prefix;
				  String frame_number_left = String.valueOf(currentvalue1);
				  String x1 = String.valueOf(leftx);
				  String y1 = String.valueOf(lefty);
				  String x2 = String.valueOf(rightx);
				  String y2 = String.valueOf(righty);
				  String secondary_video = File2Prefix;
				  String frame_number_right = String.valueOf(currentvalue2);
				  
				  //add row to jtable
				  ((DefaultTableModel)jtable.getModel()).addRow(new String[]{
						  primary_video,
						  frame_number_left,
						  x1,
						  y1,
						  x2,
						  y2,
						  secondary_video,
						  frame_number_right	  
				  });
		  }
	  });
	  
	  c.fill = GridBagConstraints.HORIZONTAL;
	  c.anchor = GridBagConstraints.WEST;
	  c.weightx = 0.5;
	  c.gridx = 0;
	  c.gridy = 5;
	  frame.getContentPane().add(SvideoText,c);
//	  
	  c.fill = GridBagConstraints.HORIZONTAL;
	  c.anchor = GridBagConstraints.WEST;
	  c.weightx = 0.5;
	  c.gridx = 1;
	  c.gridy = 5;
	  frame.getContentPane().add(btn_import2,c);
	  
	  save_file.addActionListener(new ActionListener() {
		  public void actionPerformed(ActionEvent e) {
			 int rowCount = ((DefaultTableModel)jtable.getModel()).getRowCount();
			 int colCount = ((DefaultTableModel)jtable.getModel()).getColumnCount();
			 if(rowCount == 0)
				 JOptionPane.showMessageDialog(null, "No data need to be saved!");
			 else {
				 try {
					 String[] temp = File1Prefix.split("/");
					 String name = temp[temp.length-1];
					 File outputfile = new File("/Users/gracelt/Desktop/"+name+".txt");
					 if(outputfile.exists()) {
						 outputfile.delete();
					 }
					 outputfile = new File("/Users/gracelt/Desktop/"+name+".txt");
				     BufferedWriter output = new BufferedWriter(new FileWriter(outputfile));
				     StringJoiner sj;
				     for(int i = 0; i < rowCount;i++) {
				    	 sj = new StringJoiner(",");
				    	 for(int j = 0; j < colCount;j++) {
				    		 String coldata = (String) jtable.getValueAt(i, j);
				    		 sj.add(coldata);
				    	 }
				    	 output.append(sj.toString()+"\n");
				     }
				     output.close();
				     JOptionPane.showMessageDialog(null, "Successfully saved!");
				 }catch(Exception error) {
					 error.printStackTrace();
				 }
			 }
			 
		  }
	  });
	  
	  c.fill = GridBagConstraints.HORIZONTAL;
	  c.anchor = GridBagConstraints.WEST;
	  c.weightx = 0.5;
	  c.gridx = 0;
	  c.gridy = 6;
	  frame.getContentPane().add(save_file,c);

     String[][] data = {};
  	 String[] colName = {"Primary Video","frame","x1","y1","x2","y2","Second Video","frame"};
  	 DefaultTableModel model = new DefaultTableModel(data,colName);
  	 jtable = new JTable(model);
  	 jtable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
  	 for(int i = 0; i< jtable.getColumnCount();i++) {
  		 jtable.getColumnModel().getColumn(i).setPreferredWidth(100);
  	 }
  	 jtable.addMouseListener(new MouseAdapter() {
  		 public void mouseClicked(MouseEvent e) {
  			 mouseRightClicked(e);
  		 }
  	 });
  	 jsPane = new JScrollPane(jtable);
  	 jsPane.setPreferredSize(new Dimension(352,288));
  	
 
	  c.fill = GridBagConstraints.HORIZONTAL;
	  c.anchor = GridBagConstraints.WEST;
	  c.weightx = 0.5;
	  c.gridx = 0;
	  c.gridy = 7;
	  frame.getContentPane().add(jsPane,c);
	  
	 
	  
	  frame.pack();
	  frame.setVisible(true);
	  
	  
  }
  public  void readData(String name,BufferedImage img) {
	  try {
		  File file = new File(name);
		  
		  if(file.isFile() && file.exists()) {
			 
			  FileInputStream in = new FileInputStream(file);
			  byte[] data = new byte[in.available()];
			  in.read(data);
			  in.close();
			
          	for(int i = 0; i < data.length/3;i++) {
            	byte r = data[i];
	            byte g = data[i+data.length/3];
	            byte b = data[i+data.length/3*2];
	            byte a = (byte)255;
	            int pix = ((a << 24) + (r << 16) + (g << 8) + b);
	            imagedata[i/352][i%352] = pix;
	            img.setRGB(i%352, i/352, imagedata[i/352][i%352]);
	            System.out.println(i/352+","+i%352+":"+imagedata[i/352][i%352]);
        	}
    		Graphics2D g = img.createGraphics();
    		g.drawImage(img, 0, 0, null);
			
		  }
		  
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
  }
  public static void generatePopupMenu() {
	  Popup_Menu = new JPopupMenu();
	  JMenuItem delItem = new JMenuItem();
	  delItem.setText("delete");
	  delItem.addActionListener(new ActionListener() {
		  public void actionPerformed(ActionEvent e) {
			  int index =jtable.getSelectedRow();
			  ((DefaultTableModel)jtable.getModel()).removeRow(index);
			  if(!last_leftimgs.isEmpty())
			  leftimg.setData(last_leftimgs.pop().getData());
			  frame.getContentPane().remove(lbIm1);
			  //leftimg = img;
			  frame.repaint();
			  lbIm1 = new JLabel(new ImageIcon(leftimg));
			  c.fill = GridBagConstraints.HORIZONTAL;
			  c.gridx = 0;
			  c.gridy = 1;
			  frame.getContentPane().add(lbIm1,c);
			  frame.getContentPane().validate();
		  }
	  });
	  Popup_Menu.add(delItem);
  }
  public static void mouseRightClicked(MouseEvent e) {
	  if(e.getButton() == MouseEvent.BUTTON3) {
		  System.out.print("clicked!");
		  int focusedRowIndex = jtable.rowAtPoint(e.getPoint());
          if (focusedRowIndex == -1) {
              return;
          }
          jtable.setRowSelectionInterval(focusedRowIndex, focusedRowIndex);
          generatePopupMenu();
          Popup_Menu.show(jtable, e.getX(), e.getY());
	  }
  }
}
