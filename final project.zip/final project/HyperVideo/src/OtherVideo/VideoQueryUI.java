package OtherVideo;
import java.awt.*;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Map.Entry;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Line2D;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
class Link{
	String oriFolder = "";
	String tarFolder = "";
	int oriFrame;
	int tarFrame;
	int x1;
	int x2;
	int y1;
	int y2;
	Link(String oriFolder, String tarFolder, int oriFrame, int tarFrame, int x1, int y1, int x2, int y2){
		this.oriFolder = oriFolder;
		this.tarFolder = tarFolder;
		this.oriFrame = oriFrame;
		this.tarFrame = tarFrame;
		this.x1 = x1;
		this.x2 = x2;
		this.y1 = y1;
		this.y2 = y2;
	}
}
public class VideoQueryUI extends Frame implements ActionListener {
    private ArrayList<BufferedImage> images; 
    private PlaySound playSound;
    static final int frameRate = 30;
    private JLabel imageLabel;
    //private TextField queryField;
    private Button playButton;
    private Button pauseButton;
    private Button stopButton;
    private Button loadQueryButton;
    private String fileName;
    private int playStatus = 3;//1 for play, 2 for pause, 3 for stop
    private Thread playingThread;
    private Thread audioThread;
    private int currentFrameNum = 0;
    private int totalFrameNum = 4003;
    //private String fileFolder = "/Users/yanmei/Downloads/USC";
    static final int WIDTH = 352;
    static final int HEIGHT = 288;
    ArrayList<Link> linkArr = new ArrayList<Link>();
    String txtfile = "/Users/gracelt/Desktop/output.txt";
    public String ori_dir = VideoPlayer.ori_dir;
    public String tar_dir = VideoPlayer.tar_dir;
    //= "/Users/yanmei/Downloads/NewYorkCity/NYOne";
    //String tar_dir = "/Users/yanmei/Downloads/NewYorkCity/NYTwo";
    String load_video_dir = ori_dir+"/";
    String commonName = VideoPlayer.commonName_ori;
    //= "NYOne";
    int fromNum = 1;
    //Queue<BufferedImage> cacheQueue;
//    public VideoQueryUI(String ori_dir, String tar_dir, String commonName) {
//    		this.ori_dir = ori_dir;
//    		this.tar_dir = tar_dir;
//    		this.commonName = commonName;
//    }
   
	public VideoQueryUI(ArrayList<BufferedImage> imgs) {
		  try (FileReader reader = new FileReader(txtfile);
		            BufferedReader br = new BufferedReader(reader) 
		       ) {
		           String line;
		           while ((line = br.readLine()) != null) {        
		               String[] arr = line.split(",");
		               String ori = arr[0];
		               int ori_frame = Integer.valueOf(arr[1]);
		               int x1 = Integer.valueOf(arr[2]);
		               int y1 = Integer.valueOf(arr[3]);
		               int x2 = Integer.valueOf(arr[4]);
		               int y2 = Integer.valueOf(arr[5]);
		               String tar = arr[6];
		               int tar_frame = Integer.valueOf(arr[7]);
		               linkArr.add(new Link(ori,tar,ori_frame,tar_frame,x1,y1,x2,y2));
		               
		           }
		       } catch (IOException e) {
		           e.printStackTrace();
		       }
		this.images = imgs;
		
	    //Query Panel
	    Panel queryPanel = new Panel();
	    //queryField = new TextField(13);
	    //JLabel queryLabel = new JLabel("Query: ");
	    //queryPanel.add(queryLabel);
	    //queryPanel.add(queryField);
	    loadQueryButton = new Button("Load Query Video");
	    loadQueryButton.addActionListener(this);
	    
	    
	    queryPanel.add(loadQueryButton);
//	    queryPanel.add(errorLabel);
	   
	    Panel controlQueryPanel = new Panel();
	    controlQueryPanel.setLayout(new GridLayout(2, 0));
	    controlQueryPanel.add(queryPanel);
	   
	    add(controlQueryPanel, BorderLayout.WEST);
	    
	    //Video List Panel
	    Panel listPanel = new Panel();
	    listPanel.setLayout(new GridLayout(2, 2));
	    this.imageLabel = new JLabel(new ImageIcon(images.get(currentFrameNum)));
	    Panel imagePanel = new Panel();
	    imagePanel.add(this.imageLabel);
	    
	    listPanel.add(imagePanel);
	
	    
	    //Control Panel
	    Panel controlPanel = new Panel();
	   
	    
	    playButton = new Button("PLAY");
	    playButton.addActionListener(this);
	    controlPanel.add(playButton);
	   
	    
	    pauseButton = new Button("PAUSE");
	    pauseButton.addActionListener(this);
	    controlPanel.add(pauseButton);
	  
	    
	    stopButton = new Button("STOP");
	    stopButton.addActionListener(this);
	   
	    controlPanel.add(stopButton);
	  
	    
	    listPanel.add(controlPanel);

	    add(listPanel, BorderLayout.SOUTH);
		imageLabel.addMouseListener(new MouseAdapter(){
			  int x;
			  int y;
			  
			  public void mouseClicked(MouseEvent e) {
				   x = e.getX();
				   y = e.getY();
				   for(Link list: linkArr) {
					   if(list.oriFrame == currentFrameNum) {
						  
						   if (x<=list.x2 && x>=list.x1 && y>=list.y1 && y<=list.y2) {
							   System.out.println("got it ! x is "+x+" y is:"+y + " "+list.x1+" "+list.x2+" "+list.y1+" "+list.y2);
							   load_video_dir = tar_dir+"/";
							   commonName = VideoPlayer.commonName_tar;
							   fromNum = list.tarFrame;
							  // if(playingThread != null) {
									playingThread.interrupt();
									audioThread.interrupt();

								    // cacheThread.interrupt();
							   		images.clear();
									playSound.stop();
									playingThread = null;
									audioThread = null;
									loadNextVideo(fromNum);
								//} 
						   }
					   }
				   }
				   
//				   playingThread = null;
//				   audioThread = null;
//				   loadNextVideo(fromNum);
				   System.out.println("x:"+x+",y:"+y+" currentFrameNum: "+currentFrameNum);
			  }
	});
	}
	
	public void setImages(ArrayList<BufferedImage> images){
		this.images = images;
	}
	
	public void showUI() {
	    pack();
	    setVisible(true);
	}
	
	private void playVideo() {
		playingThread = new Thread() {//
            public void run() {
	            System.out.println("Start playing video: " + currentFrameNum);
	            //totalFrameNum = cacheQueue.size();
	          	for (int i = currentFrameNum; i < 4003; i++) {
	          	  	imageLabel.setIcon(new ImageIcon(images.get(i)));
	          		//imageLabel.setIcon(new ImageIcon(cacheQueue.poll()));
	          	     currentFrameNum = i;
	          	 	//System.out.println("hello current frame "+ cacheQueue.element());
	          	    try {
	                  	sleep(1000/frameRate);//
	          	    } catch (InterruptedException e) {
	          	    	if(playStatus == 3) {
	          	    		currentFrameNum = 0;
	          	    	} else {
	          	    		currentFrameNum = i;
	          	    		System.out.println("!!!hello current frame "+ currentFrameNum);
	          	    	}
	          	    	//imageLabel.setIcon(new ImageIcon(images.get(currentFrameNum)));
	          	    //	imageLabel.setIcon(new ImageIcon(cacheQueue.element()));
	                  	currentThread().interrupt();
	                  	break;
	                }
	          	}
	          	if(playStatus < 2) {
	          		playStatus = 3;
		            currentFrameNum = 0;
	          	}
	            System.out.println("End playing video: " + currentFrameNum);
	        }
	    };
	    audioThread = new Thread() {//
            public void run() {
                try {
        	        playSound.play();
        	    } catch (PlayWaveException e) {
        	        e.printStackTrace();
        	        return;
        	    }
	        }
	    };
	    audioThread.start();
	    playingThread.start();
	}
	
	private void pauseVideo() throws InterruptedException {
		if(playingThread != null) {
			playingThread.interrupt();
			audioThread.interrupt();
			playSound.pause();
			playingThread = null;
			audioThread = null;
		}
	}
	
	private void stopVideo() {
		if(playingThread != null) {
			playingThread.interrupt();
			audioThread.interrupt();
			playSound.stop();
			playingThread = null;
			audioThread = null;
		} else {
			currentFrameNum = 0;
			//cacheQueue.clear();
			displayScreenShot();
		}
	}
//	private void stopVideo() {
//		if(playingThread != null) {
//			playingThread.interrupt();
//			playingThread = null;
//		}
//		if (audioThread != null){
//			audioThread.interrupt();
//			playSound.stop();
//			audioThread = null;
//		}
//			currentFrameNum = 0;
//			cacheQueue.clear();
//			//currentFrameNum = 0;
//	
//	}
	
	
	private void displayScreenShot() {
		Thread initThread = new Thread() {
            public void run() {
	          	imageLabel.setIcon(new ImageIcon(images.get(currentFrameNum)));  	   
	        }
	    };
	    initThread.start();
	}
	
	private void loadVideo(int fromNum) {
//		 cacheQueue = new LinkedList<BufferedImage>();
		System.out.println("Start loading query video contents. "+fromNum + " cur "+currentFrameNum);
//		Thread cacheThread = new Thread() {
//            public void run() {
		//Map<Integer,List<List<Integer>>> map = null;
	    try {
          File output_file = new File("/Users/gracelt/Desktop/output.txt");
          InputStreamReader  inputstream = new InputStreamReader(new FileInputStream(output_file));
          BufferedReader br = new BufferedReader(inputstream);
          Map<Integer,List<List<Integer>>> map = new HashMap<>();
          String line = br.readLine();
          while(line != null) {
        	  System.out.println(line);
        	  String[] record = line.split(",");
        	  int frame_number = Integer.parseInt(record[1]);
        	  List<Integer> temp_list = new ArrayList<>();
        	  for(int i = 2;i<=5;i++) {
        		  temp_list.add(Integer.parseInt(record[i]));
        	  }
        	  if(!map.containsKey(frame_number)) {
        		  List<List<Integer>> list = new ArrayList<>();
        		  map.put(frame_number, list);
        	  }
        	  map.get(frame_number).add(temp_list);
        	  line = br.readLine();
	      //images = new ArrayList<BufferedImage>();
         } 
	     
	      for(int i=fromNum; i<=4003; i++) {
	    	      
		    	  String fileNum = "000";
		    	  if(i >= 10 && i < 100)
		    		  fileNum = "00";
		    	  else if (i>=100 && i < 1000)
		    		  fileNum = "0";
		    	  else if (i>=1000)
		    		  fileNum = "";
		    	  //if(cacheQueue.size()<400){
		    		//  System.err.println(cacheQueue.size());
		    	  
		    	  String fullName = load_video_dir + commonName +fileNum+new Integer(i).toString() + ".rgb";
		    	  
		    	  //String fullName = fileFolder + "/" + userInput + "_" +fileNum + new Integer(i).toString() + ".rgb";
		    	  //String audioFilename = fileFolder + "/" + userInput + ".wav";
		    	  File file = new File(fullName);
		    	  InputStream is = new FileInputStream(file);

	   	      long len = file.length();
		      byte[] bytes = new byte[(int)len];
		      int offset = 0;
	          int numRead = 0;
	          while (offset < bytes.length && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
	              offset += numRead;
	          }
	          //System.out.println("Start loading frame: " + fullName);
	    	  	  int index = 0;
	          BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
	          for (int y = 0; y < HEIGHT; y++) {
	            for (int x = 0; x < WIDTH; x++) {
	   				byte r = bytes[index];
	   				byte g = bytes[index+HEIGHT*WIDTH];
	   				byte b = bytes[index+HEIGHT*WIDTH*2]; 
	   				int pix = 0xff000000 | ((r & 0xff) << 16) | ((g & 0xff) << 8) | (b & 0xff);
	    			image.setRGB(x,y,pix);
	    			index++;
	    		}
	    	  }
	          if(map.containsKey(i)) {
	        	  System.out.print(map.get(i).size());	
			      for(List<Integer> point_list: map.get(i)) {	  
			    	  int x1 = point_list.get(0);
			    	  int y1 = point_list.get(1);
			    	  int x2 = point_list.get(2);
			    	  int y2 = point_list.get(3);
			    	  int w  = Math.abs(x2-x1);
			    	  int h = Math.abs(y2-y1);
			    	  Graphics2D g = image.createGraphics();
			  		  g.setColor(Color.green);
			  		  g.drawRect(x1, y1, w, h);
			  		  g.drawImage(image, 0, 0, null);
			      }
			   }
	          images.add(image);
	          //cacheQueue.add(image);
	          is.close();
	          
	   //   }//end if cachesize < 400
//		    	  else{
//	            		try 
//							{
//							    Thread.sleep(200);
//								// System.out.println("read rgb InterruptedException");
//
//							} 
//							catch(InterruptedException e)
//							{
//							   currentThread().interrupt();
//							    break;
//							}
//	            	}
	          //System.out.println("End loading query frame: " + fullName);
	      }//end for
	    } catch (FileNotFoundException e) {
	      e.printStackTrace();
	    } catch (IOException e) {
	      e.printStackTrace();
	    }
//            }
//           };
           
           //System.err.println("totalframeNum is "+ totalFrameNum);
        //cacheQueue.clear();
   	    //cacheThread.start();  
   	    String audioFilename = load_video_dir + commonName + ".wav";
   	    playSound = new PlaySound(audioFilename);
	    this.playStatus = 3;
	    currentFrameNum = 0;
	    totalFrameNum = images.size();
	    //totalFrameNum = cacheQueue.size();
	    displayScreenShot();
	    System.out.println("End loading query video contents.");
	    
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.playButton) {
			System.out.println("play button clicked");
			if(this.playStatus > 1) {
				this.playStatus = 1;
				this.playVideo();
			}
		}  else if(e.getSource() == this.pauseButton) {
			System.out.println("pause button clicked");
			if(this.playStatus == 1) {
				this.playStatus = 2;
				try {
					this.pauseVideo();
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		} else if(e.getSource() == this.stopButton) {
			System.out.println("stop button clicked");
			if(this.playStatus < 3) {
				this.playStatus = 3;
				this.stopVideo();
			}
		} 
		else if(e.getSource() == this.loadQueryButton) {
			//String userInput = queryField.getText();
			//if(userInput != null && !userInput.isEmpty()) {
				this.playingThread = null;
				this.audioThread = null;
				this.loadVideo(fromNum);
			//}
		}

	}
	
	private void loadNextVideo(int fromNum) {
//		 cacheQueue = new LinkedList<BufferedImage>();
		System.out.println("Start loading query video contents. "+fromNum + " cur "+currentFrameNum);
//		Thread cacheThread = new Thread() {
//           public void run() {
		//Map<Integer,List<List<Integer>>> map = null;
	    try {
         
	     
	      for(int i=fromNum; i<=4003; i++) {
	    	      
		    	  String fileNum = "000";
		    	  if(i >= 10 && i < 100)
		    		  fileNum = "00";
		    	  else if (i>=100 && i < 1000)
		    		  fileNum = "0";
		    	  else if (i>=1000)
		    		  fileNum = "";
		    	  //if(cacheQueue.size()<400){
		    		//  System.err.println(cacheQueue.size());
		    	  
		    	  String fullName = load_video_dir + commonName +fileNum+new Integer(i).toString() + ".rgb";
		    	  
		    	  //String fullName = fileFolder + "/" + userInput + "_" +fileNum + new Integer(i).toString() + ".rgb";
		    	  //String audioFilename = fileFolder + "/" + userInput + ".wav";
		    	  File file = new File(fullName);
		    	  InputStream is = new FileInputStream(file);

	   	      long len = file.length();
		      byte[] bytes = new byte[(int)len];
		      int offset = 0;
	          int numRead = 0;
	          while (offset < bytes.length && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
	              offset += numRead;
	          }
	          //System.out.println("Start loading frame: " + fullName);
	    	  	  int index = 0;
	          BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
	          for (int y = 0; y < HEIGHT; y++) {
	            for (int x = 0; x < WIDTH; x++) {
	   				byte r = bytes[index];
	   				byte g = bytes[index+HEIGHT*WIDTH];
	   				byte b = bytes[index+HEIGHT*WIDTH*2]; 
	   				int pix = 0xff000000 | ((r & 0xff) << 16) | ((g & 0xff) << 8) | (b & 0xff);
	    			image.setRGB(x,y,pix);
	    			index++;
	    		}
	    	  }
	          
	          images.add(image);
	          //cacheQueue.add(image);
	          is.close();
	          
	   //   }//end if cachesize < 400
//		    	  else{
//	            		try 
//							{
//							    Thread.sleep(200);
//								// System.out.println("read rgb InterruptedException");
//
//							} 
//							catch(InterruptedException e)
//							{
//							   currentThread().interrupt();
//							    break;
//							}
//	            	}
	          //System.out.println("End loading query frame: " + fullName);
	      }//end for
	    } catch (FileNotFoundException e) {
	      e.printStackTrace();
	    } catch (IOException e) {
	      e.printStackTrace();
	    }
//           }
//          };
          
          //System.err.println("totalframeNum is "+ totalFrameNum);
       //cacheQueue.clear();
  	    //cacheThread.start();  
  	    String audioFilename = load_video_dir + commonName + ".wav";
  	    playSound = new PlaySound(audioFilename);
	    this.playStatus = 3;
	    currentFrameNum = 0;
	    totalFrameNum = images.size();
	    //totalFrameNum = cacheQueue.size();
	    displayScreenShot();
	    System.out.println("End loading query video contents.");
	    
	}

	
}
