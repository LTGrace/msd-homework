import numpy as np
import cv2
import sys

records={}
with open("/Users/gracelt/Desktop/NYOne"+".txt") as file:
	for line in file.readlines():
		line = line.strip("\n").split(",")
		
		source = line[0]
		source_frame = int(line[1])
		x1,y1,x2,y2 = map(int,line[2:6])
		target = line[6]
		target_frame = int(line[7])

		record = (x1,y1,x2-x1,y2-y1,target,target_frame)
		if source_frame not in records:

			records[source_frame]= set()
		records[source_frame].add(record)
for key,values in records.items():
	print key
	print values
	print 
number = 1

with open("output.txt",'w') as f:
	# f.write('abc')
	# f.writelines(['line1\n','line2'])
	# ','.join(['1','2','3'])

	for key_source_frame in records:
		# if number > 1:
		# 	break
		# number = number + 1
		print key_source_frame
		# frame_number = records[key_source_frame]
		# print frame_number
		file_name = source + "%04d"%key_source_frame + ".rgb"
		print file_name

		boxes = []

		# box_len = len(records[key_source_frame])

		box_records = []
		for x1,x2,w,h,target,target_frame in records[key_source_frame]:
			boxes.append((x1,x2,w,h))
			# if (x1,x2,w,h) not in box_records:
			# 	box_records= []
			box_records.append((target,target_frame))
			# box_records.append(target_frame)
			print x1,x2,w,h
			print box_records


		# current_frame_data = np.zeros((288,352,3),dtype=np.uint8)
		# with open(file_name,'rb') as file:
		# 	for channel in range(3):
		# 		for row in range(288):
		# 			for col in range(352):
		# 				current_frame_data[row,col,2-channel]=ord(file.read(1))

		# current_frame = current_frame_data

		# video = cv2.VideoCapture(source+".avi")

		# if not video.isOpened():
		# 	print "Fail to open video"
		# 	sys.exit()


		myTracker = cv2.MultiTracker_create()

		is_initialize = False

		current_frame_number = key_source_frame;

		while True:
			if current_frame_number > (key_source_frame + 100):
				break;
			file_name = source + "%04d"%current_frame_number + ".rgb"
			frame = np.zeros((288,352,3),dtype=np.uint8)
			with open(file_name,'rb') as file:
				for channel in range(3):
					for row in range(288):
						for col in range(352):
							frame[row,col,2-channel]=ord(file.read(1))	
			# if(current_frame_number == key_source_frame):

			# 	frame = current_frame;
			# 	print current_frame_number

			

			if not is_initialize:
				for i in range(len(boxes)):
					myTracker.add(cv2.TrackerKCF_create(), frame, boxes[i])
				is_initialize = True

			success,return_boxes = myTracker.update(frame)
			print success,return_boxes

			if not success:
				cv2.putText(frame, "Tracking failure detected", (10,80), cv2.FONT_HERSHEY_SIMPLEX, 0.75,(0,0,255),1)
				break
			else:
				i = 0
				for return_box in  return_boxes:

					current_x = int(return_box[0])
					current_y = int(return_box[1])
					current_w = int(return_box[2])
					current_h = int(return_box[3])
					current_box = (current_x,current_y,current_w,current_h)

					start_point = (current_x,current_y)
					end_point = (current_x+current_w,current_y + current_h)
					cv2.rectangle(frame,start_point,end_point,(0,255,0))
					# best_match_box = []
					# difference_sum = (352+288)*3;
					# for box_record in box_records:
					# 	c = [ abs(box_record[i] - current_box[i]) for i in range(len(box_record))]
					# 	print sum(c)
					# 	print box_record
					# 	print current_box
					# 	if difference_sum > sum(c):
					# 		best_match_box = box_record
					# 		difference_sum = sum(c)
					keep_record = []
					keep_record.append(source)
					keep_record.append(str(current_frame_number))
					keep_record.append(str(current_x))
					keep_record.append(str(current_y))
					keep_record.append(str(current_x+current_w))
					keep_record.append(str(current_y + current_h))
					keep_record.append(box_records[i][0])
					keep_record.append(str(box_records[i][1]))
					print keep_record
					i = i + 1
					f.write(','.join(keep_record))
					f.write('\n')
			current_frame_number = current_frame_number + 1
			cv2.imshow("tracking",frame)
			k = cv2.waitKey(1)
			if k == 27:
				break

def read_frame_data(source,frame_number):
	file_name = source + "%04d"%frame_number + ".rgb"
	frame = np.zeros((288,352,3),dtype=np.uint8)
	with open(file_name,'rb') as file:
		for channel in range(3):
			for row in range(288):
				for col in range(352):
					current_frame_data[row,col,2-channel]=ord(file.read(1))
	return current_frame_data
					

			

